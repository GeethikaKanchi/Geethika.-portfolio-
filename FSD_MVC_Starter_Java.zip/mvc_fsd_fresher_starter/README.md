# FSD MVC Starter – Java Spring Boot

A beginner-friendly MVC structure for a Full Stack Development (FSD) application.

## Flow
Browser/UI → Controller → Service → Repository → Database
                         ↓
                       Model

## Project structure
- controller: receives HTTP requests and returns responses
- model: represents application data
- service: contains business logic
- repository: database access layer
- resources: configuration/static files

## Example
GET /api/users/1
→ UserController
→ UserService
→ UserRepository
→ User model returned as JSON

## Recommended next steps
1. Install JDK 17+ and IntelliJ IDEA/Eclipse.
2. Create a Spring Boot project with Spring Web and Spring Data JPA.
3. Add MySQL driver when connecting a database.
4. Replace the placeholder classes with Spring Boot annotations and logic.
