package com.example.fsd.repository;

// In a real Spring Boot + JPA project:
// public interface UserRepository extends JpaRepository<User, Long> {}

public class UserRepository {
    // Database access belongs here.
}
