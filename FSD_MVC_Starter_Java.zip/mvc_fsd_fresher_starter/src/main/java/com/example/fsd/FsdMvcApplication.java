package com.example.fsd;

public class FsdMvcApplication {
    public static void main(String[] args) {
        // SpringApplication.run(FsdMvcApplication.class, args);
    }
}
