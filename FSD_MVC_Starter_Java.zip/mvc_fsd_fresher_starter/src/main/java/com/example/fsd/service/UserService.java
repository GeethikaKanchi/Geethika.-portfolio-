package com.example.fsd.service;

import com.example.fsd.model.User;

// @Service
public class UserService {

    public User getUserById(Long id) {
        // Business logic goes here.
        return new User(id, "Sample User", "sample@example.com");
    }
}
