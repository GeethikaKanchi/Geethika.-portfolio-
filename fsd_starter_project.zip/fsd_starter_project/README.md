# FSD Starter Project

A beginner-friendly Full Stack Development starter project.

## Structure
- frontend/index.html
- frontend/style.css
- frontend/script.js
- backend/server.js

## Run
1. Open frontend/index.html in a browser to view the frontend.
2. Backend requires Node.js:
   - cd backend
   - npm init -y
   - npm install express
   - node server.js
