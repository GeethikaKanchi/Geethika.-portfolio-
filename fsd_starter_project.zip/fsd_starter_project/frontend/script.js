document.getElementById("helloBtn").addEventListener("click", () => {
  document.getElementById("message").textContent =
    "Frontend is working successfully!";
});
